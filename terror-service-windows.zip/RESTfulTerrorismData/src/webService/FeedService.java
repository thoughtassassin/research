package webService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;

import org.apache.catalina.connector.Request;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import model.ProjectManager;

import com.google.gson.Gson;

import dto.FeedObjects;

@Path("/WebService")
public class FeedService {

	@GET
	@Path("/GetFeeds")
	@Produces("application/json")
	public String feed()
	{
		String feeds = null;
		try
		{
			ArrayList<FeedObjects> feedData = null;
			ProjectManager projectManager= new ProjectManager();
			feedData = projectManager.GetFeeds();
			Gson gson = new Gson();
			System.out.println(gson.toJson(feedData));
			feeds = gson.toJson(feedData);
			//System.out.println("Are we doing anything?");
			
		}
		
		catch (Exception e)
		{
			System.out.println("Exception Error:" + e.getMessage()); //Console
		}
			return feeds;
	}
	
	@GET
	@Path("/GetMethod")
	@Produces(MediaType.TEXT_PLAIN)
	public String newMethod(
			@QueryParam("terrorParam1") String terrorParam1,
			@QueryParam("terrorParam2") String terrorParam2)
	{
		return "These are your two params---->"
				+ terrorParam1 + " and " + terrorParam2;
	}
	

}
