package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import dto.FeedObjects;

public class Project
{
public ArrayList<FeedObjects> GetFeeds(Connection connection) throws Exception
{
	ArrayList<FeedObjects> feedData = new ArrayList<FeedObjects>();
	try
	{
		PreparedStatement ps = connection.prepareStatement("SELECT gname, count(gname) AS number FROM `terrorism_data` GROUP BY gname ORDER BY number DESC");
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			FeedObjects feedObject = new FeedObjects();
			feedObject.setGroup(rs.getString("gname"));
			feedObject.setNumberOfAttacks(rs.getString("number"));
			feedData.add(feedObject);
		}
		return feedData;
	}
	catch(Exception e)
	{
		System.out.println("Error Here");
		throw e;
	}
}

}