package dto;

public class FeedObjects {

	private String group;
	private String numberOfAttacks;
	
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getNumberOfAttacks() {
		return numberOfAttacks;
	}
	public void setNumberOfAttacks(String numberOfAttacks) {
		this.numberOfAttacks = numberOfAttacks;
	}

}