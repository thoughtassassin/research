package com.example.jsonapp;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class JSONListActivity3 extends Activity {
	
	public String group;
	public JSONArray number;
	private TextView attacksView;
	private LinearLayout layout;
	private Spinner spinner1, spinner2;
	private String serverURL;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jsonlist);
		
		serverURL = "10.0.1.3:8080";
		
		Button b = (Button) findViewById(R.id.databutton);
		layout = (LinearLayout) findViewById(R.id.chartLayout);
		spinner1 = (Spinner) findViewById(R.id.yearStart);
		spinner2 = (Spinner) findViewById(R.id.yearEnd);
		
		HttpClient httpClient = new DefaultHttpClient();
		HttpContext localContext = new BasicHttpContext();
		HttpGet httpGet = new HttpGet("http://" + serverURL + "/TerrorismData/TerrorData/WebService/GetMinAndMaxYear");
		String text = null;
		JSONObject json = null;
		String minYear = "";
		String maxYear = "";
		
		try {
			
			HttpResponse response = httpClient.execute(httpGet, localContext);
			
			HttpEntity entity = response.getEntity();
			
			text = getASCIIContentFromEntity(entity);
			
			json = new JSONObject(text);
		    maxYear = json.getString("max-year");
		    minYear = json.getString("min-year");
			System.out.println("output is " + json);

		}
		catch (Exception e)
		{
			System.out.println("Problem getting max and min year --> " + e.getMessage());
		}
		
		List<String> list = new ArrayList<String>();
		for (int i = Integer.parseInt(minYear); i <= Integer.parseInt(maxYear); i++ )
		{
			list.add(Integer.toString(i)); 
		}
		
		addItemsOnSpinner1(list);
		addItemsOnSpinner2(list);
		
	}
	
	public void addItemsOnSpinner1(List<String> list) {
		 
		
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
			R.layout.custom_spinner, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner1.setAdapter(dataAdapter);
	  }
	
	public void addItemsOnSpinner2(List<String> list) {
		 
		ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
				R.layout.custom_spinner, list);
		dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner2.setAdapter(dataAdapter);
	  }
	
	 public void myClickHandler(View target) {
			
			try {
				
				String startYear = String.valueOf(spinner1.getSelectedItem());
				String endYear = String.valueOf(spinner2.getSelectedItem());
				
				if ( Integer.parseInt(startYear) >=  Integer.parseInt(endYear))
				{
			    	 Context context = getApplicationContext(); 
					 CharSequence text = "Start Year must be less than End Year";
			    	 int duration = Toast.LENGTH_SHORT;

			    	 Toast toast = Toast.makeText(context, text, duration);
			    	 toast.show();
				}
				else
				{
					new GetRESTResponseTask().execute("http://" + serverURL + "/TerrorismData/TerrorData/WebService/GetAttacksByYear?yearStart=" + startYear + "&yearEnd=" + endYear);			
				}
			
			} catch (Exception e) {
				
				System.out.println("Error is in clickHandler --> " + e.getLocalizedMessage());
			
			}
			

	 }
	
	 private class GetRESTResponseTask extends AsyncTask<String, Void, JSONArray> {
		 
		ProgressDialog progressDialog;
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		GraphicalView mChartView = null;
		
		//Ten Renderers
		XYSeriesRenderer renderer = new XYSeriesRenderer();
		XYSeriesRenderer renderer2 = new XYSeriesRenderer();
		XYSeriesRenderer renderer3 = new XYSeriesRenderer();
		XYSeriesRenderer renderer4 = new XYSeriesRenderer();
		XYSeriesRenderer renderer5 = new XYSeriesRenderer();
		XYSeriesRenderer renderer6 = new XYSeriesRenderer();
		XYSeriesRenderer renderer7 = new XYSeriesRenderer();
		XYSeriesRenderer renderer8 = new XYSeriesRenderer();
		XYSeriesRenderer renderer9 = new XYSeriesRenderer();
		XYSeriesRenderer renderer10 = new XYSeriesRenderer();
		
		//ArrayList for renderers
		ArrayList<XYSeriesRenderer> rendererList = new ArrayList<XYSeriesRenderer>();
		
		XYMultipleSeriesRenderer mRenderer = new XYMultipleSeriesRenderer();
		
		protected void onPreExecute()
	    {
			progressDialog= ProgressDialog.show(JSONListActivity3.this, "Data Progress","Processing Request", true);

	        //do initialization of required objects objects here                
	    }
	     protected void onProgressUpdate() {
	         //setProgressPercent(progress[0]);
	     }

	     protected void onPostExecute(JSONArray newJSON) {
	    	 Context context = getApplicationContext();
	    	 CharSequence text = "Data Downloaded";
	    	 int duration = Toast.LENGTH_SHORT;
	    	 
	    	 System.out.println("Default message");

	    	 Toast toast = Toast.makeText(context, text, duration);
	    	 toast.show();
	    	 
	    	 System.out.println(dataset.toString());
	    	
	    	 mChartView = ChartFactory.getLineChartView(context, dataset, mRenderer);
	    	 mChartView.repaint();
	    	 layout.removeAllViews();
	    	 layout.addView(mChartView);
	    	 System.out.println("Build block");	    	
	    	 
	    	 
	    	 progressDialog.dismiss();
	    	 
	    	 //attacksView.setText(newJSON.toString());
	     }

		@Override
		protected JSONArray doInBackground(String... urls) {
			
			HttpClient httpClient = new DefaultHttpClient();
			HttpContext localContext = new BasicHttpContext();
			HttpGet httpGet = new HttpGet(urls[0]);
			String text = null;
			JSONArray json = null;
			
			try {
				
				HttpResponse response = httpClient.execute(httpGet, localContext);
				
				HttpEntity entity = response.getEntity();
				
				text = getASCIIContentFromEntity(entity);
				
				json = new JSONArray(text);
				
				//create an arraylist of 10 renders
				renderer.setColor(Color.WHITE);
				renderer.setPointStyle(PointStyle.SQUARE);
				renderer.setFillPoints(true);
				
				renderer2.setColor(Color.rgb(255,255,0));
				renderer2.setPointStyle(PointStyle.SQUARE);
				renderer2.setFillPoints(true);
				
				renderer3.setColor(Color.rgb(152,251,152));
				renderer3.setPointStyle(PointStyle.SQUARE);
				renderer3.setFillPoints(true);
				
				renderer4.setColor(Color.rgb(238,130,238));
				renderer4.setPointStyle(PointStyle.SQUARE);
				renderer4.setFillPoints(true);
				
				renderer5.setColor(Color.rgb(102,205,170));
				renderer5.setPointStyle(PointStyle.SQUARE);
				renderer5.setFillPoints(true);
				
				renderer6.setColor(Color.rgb(127,255,212));
				renderer6.setPointStyle(PointStyle.SQUARE);
				renderer6.setFillPoints(true);
				
				renderer7.setColor(Color.rgb(0,191,255));
				renderer7.setPointStyle(PointStyle.SQUARE);
				renderer7.setFillPoints(true);
				
				renderer8.setColor(Color.rgb(255,127,80));
				renderer8.setPointStyle(PointStyle.SQUARE);
				renderer8.setFillPoints(true);
				
				renderer9.setColor(Color.rgb(218,165,32));
				renderer9.setPointStyle(PointStyle.SQUARE);
				renderer9.setFillPoints(true);
				
				renderer10.setColor(Color.rgb(164,149,255));
				renderer10.setPointStyle(PointStyle.SQUARE);
				renderer10.setFillPoints(true);
				
				rendererList.add(renderer);
				rendererList.add(renderer2);
				rendererList.add(renderer3);
				rendererList.add(renderer4);
				rendererList.add(renderer5);
				rendererList.add(renderer6);
				rendererList.add(renderer7);
				rendererList.add(renderer8);
				rendererList.add(renderer9);
				rendererList.add(renderer10);				
				
				mRenderer = new XYMultipleSeriesRenderer();
				mRenderer.setApplyBackgroundColor(true);
				mRenderer.setBackgroundColor(Color.BLACK);
				mRenderer.setShowGrid(true);
				mRenderer.setChartTitle("Top Ten Terror Groups By Year");
				mRenderer.setFitLegend(true);
				//System.out.println("Textbox is " + mRenderer.isFitLegend());
				mRenderer.setLegendTextSize( 16 );
				
				//System.out.println("Response length is " + json.length());
				
				for (int i = 0; i < json.length(); i++) {
				    JSONObject row = json.getJSONObject(i);
				    group = row.getString("groupName");
				    number = row.getJSONArray("attacksDuringYears");
				    
				    System.out.println(group); 
				    TimeSeries series = new TimeSeries(group);
				    
				    for (int j = 0; j < number.length(); j++) {
	
				    	JSONObject attacks = number.getJSONObject(j);
				    	series.add(attacks.getInt("year"),attacks.getInt("attacks"));
				    	
				    	//System.out.println( attacks.getInt("year") + ": "
				    				      //+ attacks.getInt("attacks"));
				    }
				    
				    dataset.addSeries(series);
				    mRenderer.addSeriesRenderer(rendererList.get(i));
				    //System.out.println("Group: " + group + ", Number Of Attacks: " + number);
				 
				}				
				
			}
			catch (Exception e)
			{
				System.out.println("Error in AsyncTask -->" + e.getMessage());
			}
	       
	         return json;
		}

	 }

	
	public String getASCIIContentFromEntity(HttpEntity entity) throws IllegalStateException, IOException {
	
		InputStream in = entity.getContent();
		
		StringBuffer out = new StringBuffer();
		int n = 1;
		while (n>0) 
		{
			byte[] b = new byte[4096];
		
			n =  in.read(b);
		
			if (n>0) out.append(new String(b, 0, n));
		
		}
		
		return out.toString();
	
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jsonlist, menu);
		return true;
	}

}

