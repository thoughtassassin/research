package com.example.jsonapp;

import java.io.InputStreamReader;
import java.io.Reader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONObject;

import java.io.FileReader;
import java.util.ArrayList;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.JsonParser;
import com.google.gson.Gson;

public class RESTGraphData {

	public void getRestData( String RESTurl )
	{
				
		HttpClient httpClient = new DefaultHttpClient();
		HttpContext localContext = new BasicHttpContext();
		HttpGet httpGet = new HttpGet(RESTurl);
			
		try {
			
			HttpResponse response = httpClient.execute(httpGet, localContext);
			HttpEntity entity = response.getEntity();
			
			Reader reader = new InputStreamReader(entity.getContent());
			
			JsonParser parser = new JsonParser();
		    JsonElement element = parser.parse(reader);
		    
		    JSONObject jsonObj = new JSONObject(element.toString());
		    System.out.println(jsonObj);
		    
	        
			
		} catch (Exception e) {
			
			System.out.println("Error is in RESTGraphData --> " + e.getLocalizedMessage());
		
		}
			
	}

}
