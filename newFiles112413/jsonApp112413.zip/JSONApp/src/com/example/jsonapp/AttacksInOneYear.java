package com.example.jsonapp;

public class AttacksInOneYear {
	
	private int year;
	private int attacks;
	
	public AttacksInOneYear(int newYear, int newAttacks)
	{
		this.year = newYear;
		this.attacks = newAttacks;
	}
	
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getAttacks() {
		return attacks;
	}

	public void setAttacks(int attacks) {
		this.attacks = attacks;
	}
	
	
}