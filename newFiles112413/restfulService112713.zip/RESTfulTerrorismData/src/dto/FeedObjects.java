package dto;

public class FeedObjects {

	private String group;
	private String numberOfAttacks;
	private String year;
	
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getNumberOfAttacks() {
		return numberOfAttacks;
	}
	public void setNumberOfAttacks(String numberOfAttacks) {
		this.numberOfAttacks = numberOfAttacks;
	}

}