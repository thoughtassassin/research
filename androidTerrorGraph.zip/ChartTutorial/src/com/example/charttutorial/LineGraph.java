package com.example.charttutorial;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;

public class LineGraph {
	
	public Intent getIntent(Context context)
	{
		
		int[] x = { 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000 }; //x values
		int[] y = { 30, 34, 45, 57, 77, 89, 100, 111, 123, 145, 180 }; //y values
		TimeSeries series = new TimeSeries("Taliban");
		for ( int i = 0; i < x.length; i++ )
		{
			series.add(x[i],y[i]);
		}
		
		int[] x2 = { 1990, 1991, 1992, 1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000 }; // x values!
		int[] y2 =  { 180, 145, 123, 111, 100, 89, 77, 57, 45, 34, 30}; // y values!
		TimeSeries series2 = new TimeSeries("IRA");
		for ( int i = 0; i < x.length; i++ )
		{
			series2.add(x2[i],y2[i]);
		}
		
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		dataset.addSeries(series);
		dataset.addSeries(series2);
		
		//first series renderer
		XYSeriesRenderer renderer = new XYSeriesRenderer();
		renderer.setColor(Color.WHITE);
		renderer.setPointStyle(PointStyle.SQUARE);
		renderer.setFillPoints(true);
		
		//first series renderer2
		XYSeriesRenderer renderer2 = new XYSeriesRenderer();
		renderer2.setColor(Color.YELLOW);
		renderer2.setPointStyle(PointStyle.DIAMOND);
		renderer2.setFillPoints(true);
		
		XYMultipleSeriesRenderer mRenderer = new XYMultipleSeriesRenderer();
		mRenderer.setApplyBackgroundColor(true);
		mRenderer.setBackgroundColor(Color.BLACK);
		mRenderer.setShowGrid(true);
		mRenderer.addSeriesRenderer(renderer);
		mRenderer.addSeriesRenderer(renderer2);
		mRenderer.setChartTitle("Number of Terrorist Attacks");
		
		Intent intent = ChartFactory.getLineChartIntent( context, dataset, mRenderer, "Line Graph Title");
		return intent;
	}
	
}
