package com.example.jsonapp;

import java.util.Comparator;

public class AttackInOneYearComparator implements Comparator<AttacksInOneYear> {
    @Override
    public int compare(AttacksInOneYear year1, AttacksInOneYear year2) {
       
    	if (year1.getYear() > year2.getYear())
    	{
    		return 1;
    	}
    	else if (year1.getYear() > year2.getYear())
    	{
    		return -1;
    	}
    	
    	return 0;
    	
    }
}