package com.example.jsonapp;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.achartengine.ChartFactory;
import org.achartengine.GraphicalView;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.TimeSeries;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Color;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class JSONListActivity3 extends Activity {
	
	public String group;
	public JSONArray number;
	private TextView attacksView;
	private LinearLayout layout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jsonlist);
		
		Button b = (Button) findViewById(R.id.databutton);
		//attacksView = (TextView) findViewById(R.id.attacksTextView);
		layout = (LinearLayout) findViewById(R.id.chartLayout);
	}
	
	 public void myClickHandler(View target) {
			
			try {
				
				
				new GetRESTResponseTask().execute("http://204.158.167.11:8080/TerrorismData/TerrorData/WebService/GetAttacksByYear?yearStart=1990&yearEnd=2010");			
			
			
			} catch (Exception e) {
				
				System.out.println("Error is in clickHandler --> " + e.getLocalizedMessage());
			
			}
			

	 }
	
	 private class GetRESTResponseTask extends AsyncTask<String, Void, JSONArray> {
		 
		ProgressDialog progressDialog;
		XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
		XYSeriesRenderer renderer = new XYSeriesRenderer();
		XYMultipleSeriesRenderer mRenderer = new XYMultipleSeriesRenderer();
		
		protected void onPreExecute()
	    {
			progressDialog= ProgressDialog.show(JSONListActivity3.this, "Data Progress","Processing Request", true);

	        //do initialization of required objects objects here                
	    }
	     protected void onProgressUpdate() {
	         //setProgressPercent(progress[0]);
	     }

	     protected void onPostExecute(JSONArray newJSON) {
	    	 Context context = getApplicationContext();
	    	 CharSequence text = "Data Downloaded";
	    	 int duration = Toast.LENGTH_SHORT;
	    	 GraphicalView mChartView = null;

	    	 Toast toast = Toast.makeText(context, text, duration);
	    	 toast.show();
	    	 mChartView = ChartFactory.getLineChartView(context, dataset, mRenderer);
	    	 layout.addView(mChartView);
	    	 progressDialog.dismiss();
	    	 
	    	 //attacksView.setText(newJSON.toString());
	     }

		@Override
		protected JSONArray doInBackground(String... urls) {
			
			HttpClient httpClient = new DefaultHttpClient();
			HttpContext localContext = new BasicHttpContext();
			HttpGet httpGet = new HttpGet(urls[0]);
			String text = null;
			JSONArray json = null;
			
			try {
				
				HttpResponse response = httpClient.execute(httpGet, localContext);
				
				HttpEntity entity = response.getEntity();
				
				text = getASCIIContentFromEntity(entity);
				
				json = new JSONArray(text);
				
				renderer.setColor(Color.WHITE);
				renderer.setPointStyle(PointStyle.SQUARE);
				renderer.setFillPoints(true);
				mRenderer = new XYMultipleSeriesRenderer();
				mRenderer.setApplyBackgroundColor(true);
				mRenderer.setBackgroundColor(Color.BLACK);
				mRenderer.setShowGrid(true);
				mRenderer.setChartTitle("Number of Terrorist Attacks");
				
				for (int i = 0; i < json.length(); i++) {
				    JSONObject row = json.getJSONObject(i);
				    group = row.getString("groupName");
				    number = row.getJSONArray("attacksDuringYears");
				    
				    //System.out.println(group); 
				    TimeSeries series = new TimeSeries(group);
				    
				    for (int j = 0; j < number.length(); j++) {
	
				    	JSONObject attacks = number.getJSONObject(j);
				    	series.add(attacks.getInt("year"),attacks.getInt("attacks"));
				    	
				    	//System.out.println( attacks.getInt("year") + ": "
				    				      //+ attacks.getInt("attacks"));
				    }
				    
				    dataset.addSeries(series);
				    mRenderer.addSeriesRenderer(renderer);
				    //System.out.println("Group: " + group + ", Number Of Attacks: " + number);
				 
				}				
				
			}
			catch (Exception e)
			{
				System.out.println("Error in AsyncTask -->" + e.getMessage());
			}
	       
	         return json;
		}

	 }

	
	public String getASCIIContentFromEntity(HttpEntity entity) throws IllegalStateException, IOException {
	
		InputStream in = entity.getContent();
		
		StringBuffer out = new StringBuffer();
		int n = 1;
		while (n>0) 
		{
			byte[] b = new byte[4096];
		
			n =  in.read(b);
		
			if (n>0) out.append(new String(b, 0, n));
		
		}
		
		return out.toString();
	
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jsonlist, menu);
		return true;
	}

}

