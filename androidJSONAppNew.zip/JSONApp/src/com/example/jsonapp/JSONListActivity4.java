package com.example.jsonapp;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONObject;

import android.os.Bundle;
import android.app.ListActivity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class JSONListActivity4 extends ListActivity {
	
	public String group;
	public String number;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jsonlist);
		
		Button b = (Button) findViewById(R.id.databutton);
		
		System.out.print("output number one");
		
		
	}
	
	 public void myClickHandler(View target) {
		 //Toast.makeText(getApplicationContext(), "msg msg", Toast.LENGTH_SHORT).show();
	        
	    RESTData terrorData = new RESTData();
		 
        ArrayList<HashMap<String, String>> terrorList = terrorData.getRestData("http://204.158.168.246:8080/TerrorismData/TerrorData/WebService/GetTopTen?terrorParam1=1990&terrorParam2=2011");
		// Hashmap for ListView;
        System.out.println(terrorList);
	
		ListAdapter adapter = new SimpleAdapter(this, terrorList,
                R.layout.datacell,
                new String[] { "group", "attacks" }, new int[] { R.id.terrorGroup, R.id.numberOfAttacks });
 
        setListAdapter(adapter);
 
        // selecting single ListView item
        ListView lv = getListView();
		 
	 }
	
	public String getASCIIContentFromEntity(HttpEntity entity) throws IllegalStateException, IOException {
	
		InputStream in = entity.getContent();
		
		StringBuffer out = new StringBuffer();
		int n = 1;
		while (n>0) 
		{
			byte[] b = new byte[4096];
		
			n =  in.read(b);
		
			if (n>0) out.append(new String(b, 0, n));
		
		}
		
		return out.toString();
	
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jsonlist, menu);
		return true;
	}

}

