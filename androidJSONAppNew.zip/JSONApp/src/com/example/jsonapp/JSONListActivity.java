package com.example.jsonapp;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.JsonObject;

import android.os.Bundle;
import android.app.ListActivity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class JSONListActivity extends ListActivity {
	
	public String group;
	public String number;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jsonlist);
		
		Button b = (Button) findViewById(R.id.databutton);
		
		
	}
	
	 public void myClickHandler(View target) {
		 //Toast.makeText(getApplicationContext(), "msg msg", Toast.LENGTH_SHORT).show();
	        
	    RESTGraphData terrorData = new RESTGraphData();
		 
	    terrorData.getRestData("http://10.0.1.3:8080/TerrorismData/TerrorData/WebService/GetAttacksByYear?yearStart=1990&yearEnd=2010");
		
        
        try {

	        
        } catch (Exception e) {
				
				System.out.println("Error is in list activity --> " + e.getLocalizedMessage());
			
		}
        
       
	 }
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.jsonlist, menu);
		return true;
	}

}

