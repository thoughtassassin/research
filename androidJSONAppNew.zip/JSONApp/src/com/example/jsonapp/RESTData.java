package com.example.jsonapp;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONArray;
import org.json.JSONObject;

public class RESTData {

	public ArrayList<HashMap<String, String>> getRestData( String RESTurl )
	{
		
		String group, attacks;
		
		//List to return HashMap ArrayList to use in a simple adapter
		ArrayList<HashMap<String, String>> newList = new ArrayList<HashMap<String, String>>();
		
		HttpClient httpClient = new DefaultHttpClient();
		HttpContext localContext = new BasicHttpContext();
		HttpGet httpGet = new HttpGet(RESTurl);
		String text = null;
			
		try {
			
			HttpResponse response = httpClient.execute(httpGet, localContext);
			
			HttpEntity entity = response.getEntity();
			
			text = getASCIIContentFromEntity(entity);
			
			JSONArray json = new JSONArray(text);
			
			System.out.println(json.length());

			for (int i = 0; i < json.length(); i++) {
				
			    JSONObject row = json.getJSONObject(i);
			    
			    group = row.getString("group");
			    attacks = row.getString("numberOfAttacks");
			    System.out.println("Group: " + group + ", Number Of Attacks: " + attacks);
			    
				HashMap<String, String> map = new HashMap<String, String>();

			    // adding each child node to HashMap key => value
                map.put("group", group);
                map.put("attacks", attacks);
 
                // adding HashList to ArrayList
                newList.add(map);
			}
		
			
			
		} catch (Exception e) {
			
			System.out.println("Error is in last catch --> " + e.getLocalizedMessage());
		
		}
		
		
		System.out.println(newList);
		return newList;
		
	}
	
	public String getASCIIContentFromEntity(HttpEntity entity) throws IllegalStateException, IOException {
		
		InputStream in = entity.getContent();
		
		StringBuffer out = new StringBuffer();
		int n = 1;
		while (n>0) 
		{
			byte[] b = new byte[4096];
		
			n =  in.read(b);
		
			if (n>0) out.append(new String(b, 0, n));
		
		}
		
		return out.toString();
	
	}

}
